var loadadvertonce = false, loadadvertlae = null;
function loadadvert() {
	try {
		getKaiAd;
	} catch(e) {
		console.log(e);
		return;
	}

	if(!loadadvertonce) {
		loadadvertlae = document.activeElement;

		getKaiAd({
			publisher: '', //test only please
			app: '',
			test: 1,
			onerror: err => console.error('Custom catch:', err),
			onready: ad => {
				// Ad is ready to be displayed
				// calling 'display' will display the ad
				ad.call('display');

				ad.on('close', () => {
					loadadvertlae.focus();
					loadadvertlae = null;
				});
			}
		});

	loadadvertonce = true;
	}
}
